import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib
matplotlib.use('Agg') 
import matplotlib.pyplot as plt
plt.switch_backend('Agg')
%matplotlib inline
sns.set(style='whitegrid', palette='muted', font_scale=1.1)

df = pd.read_csv("dataset/lung_disease_data.csv")
df

numeric_cols = ['Age', 'Lung Capacity', 'Hospital Visits']
categorical_cols = ['Gender', 'Smoking Status', 'Disease Type', 'Treatment Type', 'Recovered']

for col in numeric_cols:
    if df[col].isnull().sum() > 0:
        median_val = df[col].median()
        df[col].fillna(median_val, inplace=True)
        print(f"Filled missing values in {col} with median value {median_val}")

for col in categorical_cols:
    if df[col].isnull().sum() > 0:
        mode_val = df[col].mode()[0]
        df[col].fillna(mode_val, inplace=True)
        print(f"Filled missing values in {col} with mode value '{mode_val}'")

df['Recovered_binary'] = df['Recovered'].apply(lambda x: 1 if x.lower() == 'yes' else 0)

print('\nMissing values after imputation:')

plt.figure(figsize=(12, 4))
for i, col in enumerate(numeric_cols):
    plt.subplot(1, 3, i+1)
    sns.histplot(df[col], kde=True, bins=20)
    plt.title(f'Distribution of {col}')
plt.tight_layout()
plt.show()

plt.figure(figsize=(14, 8))

plt.subplot(2, 2, 1)
sns.countplot(x='Gender', data=df, palette='viridis')
plt.title('Gender Distribution')

plt.subplot(2, 2, 2)
sns.countplot(x='Smoking Status', data=df, palette='magma')
plt.title('Smoking Status Distribution')

plt.subplot(2, 2, 3)
sns.countplot(x='Disease Type', data=df, palette='cool')
plt.title('Disease Type Distribution')

plt.subplot(2, 2, 4)
sns.countplot(x='Treatment Type', data=df, palette='cubehelix')
plt.title('Treatment Type Distribution')

plt.tight_layout()
plt.show()

plt.figure(figsize=(10, 6))
sns.boxplot(data=df[numeric_cols], orient='h')
plt.title('Box Plot of Numeric Features')
plt.tight_layout()
plt.show()

sns.pairplot(df[numeric_cols])
plt.show()

features = ['Age', 'Lung Capacity', 'Hospital Visits']
categorical_features = ['Gender', 'Smoking Status', 'Disease Type', 'Treatment Type']


df_model = df[features + categorical_features].copy()


df_encoded = pd.get_dummies(df_model, drop_first=True)

X = df_encoded
y = df['Recovered_binary']


from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)


from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, confusion_matrix, roc_curve, auc

model = LogisticRegression(max_iter=1000)
model.fit(X_train, y_train)

y_pred = model.predict(X_test)

accuracy = accuracy_score(y_test, y_pred)
print('Prediction Accuracy: {:.2f}%'.format(accuracy * 100))

conf_matrix = confusion_matrix(y_test, y_pred)
plt.figure(figsize=(6, 5))
sns.heatmap(conf_matrix, annot=True, fmt='d', cmap='Blues')
plt.title('Confusion Matrix')
plt.xlabel('Predicted')
plt.ylabel('Actual')
plt.tight_layout()
plt.show()

y_pred_proba = model.predict_proba(X_test)[:, 1]
fpr, tpr, thresholds = roc_curve(y_test, y_pred_proba)
roc_auc = auc(fpr, tpr)

plt.figure(figsize=(8, 6))
plt.plot(fpr, tpr, color='darkorange', label='ROC curve (area = {:.2f})'.format(roc_auc))
plt.plot([0, 1], [0, 1], color='navy', linestyle='--')
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('Receiver Operating Characteristic (ROC)')
plt.legend(loc='lower right')
plt.tight_layout()
plt.show()













