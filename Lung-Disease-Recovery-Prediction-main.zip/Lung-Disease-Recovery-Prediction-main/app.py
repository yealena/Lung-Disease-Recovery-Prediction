import streamlit as st
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
import pickle
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, confusion_matrix, roc_curve, auc
import time
from PIL import Image

# Set page configuration
st.set_page_config(
    page_title="Lung Disease Recovery Predictor",
    page_icon="🫁",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS to improve appearance
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        color: #3366ff;
        text-align: center;
        margin-bottom: 1rem;
    }
    .sub-header {
        font-size: 1.8rem;
        color: #4a4a4a;
        margin-top: 2rem;
        margin-bottom: 1rem;
    }
    .card {
        background-color: #f9f9f9;
        border-radius: 10px;
        padding: 20px;
        box-shadow: 0 4px 6px rgba(0, 0, 0,.1);
        margin-bottom: 20px;
    }
    .info-text {
        font-size: 1rem;
        color: #666;
    }
    .success-message {
        background-color: #d4edda;
        color: #155724;
        padding: 10px;
        border-radius: 5px;
        margin-bottom: 10px;
    }
    .stButton button {
        background-color: #3366ff;
        color: white;
        font-weight: bold;
        border-radius: 5px;
        padding: 0.5rem 1rem;
        border: none;
    }
    .stButton button:hover {
        background-color: #254EDB;
    }
    .metrics-container {
        display: flex;
        justify-content: space-between;
    }
    .metric-card {
        background-color: #f0f8ff;
        border-radius: 8px;
        padding: 15px;
        margin: 10px;
        text-align: center;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }
</style>
""", unsafe_allow_html=True)

@st.cache_data
def load_data():
    try:
        df = pd.read_csv("dataset/lung_disease_data.csv")
        return df
    except:
        # Creating dummy data if real data not available
        np.random.seed(42)
        data = {
            'Patient ID': [f'P{i:03d}' for i in range(1, 201)],
            'Age': np.random.randint(18, 85, 200),
            'Gender': np.random.choice(['Male', 'Female'], 200),
            'Smoking Status': np.random.choice(['Never Smoker', 'Former Smoker', 'Current Smoker'], 200),
            'Lung Capacity': np.random.normal(80, 15, 200),
            'Disease Type': np.random.choice(['Asthma', 'COPD', 'Pneumonia', 'Bronchitis', 'Lung Cancer'], 200),
            'Treatment Type': np.random.choice(['Medication', 'Surgery', 'Radiation', 'Combination'], 200),
            'Hospital Visits': np.random.randint(1, 15, 200),
            'Recovered': np.random.choice(['Yes', 'No'], 200, p=[0.7, 0.3])
        }
        df = pd.DataFrame(data)
        return df

@st.cache_data
def preprocess_data(df):
    numeric_cols = ['Age', 'Lung Capacity', 'Hospital Visits']
    categorical_cols = ['Gender', 'Smoking Status', 'Disease Type', 'Treatment Type', 'Recovered']
    
    # Handle missing values
    for col in numeric_cols:
        df[col].fillna(df[col].median(), inplace=True)
    
    for col in categorical_cols:
        df[col].fillna(df[col].mode()[0], inplace=True)
    
    # Create binary target
    df['Recovered_binary'] = df['Recovered'].apply(lambda x: 1 if str(x).lower() == 'yes' else 0)
    
    # Prepare model features
    features = ['Age', 'Lung Capacity', 'Hospital Visits']
    categorical_features = ['Gender', 'Smoking Status', 'Disease Type', 'Treatment Type']
    df_model = df[features + categorical_features].copy()
    df_encoded = pd.get_dummies(df_model, drop_first=True)
    X = df_encoded
    y = df['Recovered_binary']
    return X, y, df

def train_and_save_model(X, y):
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    with st.spinner('Training model... Please wait.'):
        model = LogisticRegression(max_iter=1000, solver='liblinear')
        model.fit(X_train, y_train)
        
        try:
            with open("model.pkl", "wb") as f:
                pickle.dump(model, f)
        except:
            st.warning("Unable to save model to disk. Model will be used for this session only.")
    
    y_pred = model.predict(X_test)
    y_pred_proba = model.predict_proba(X_test)[:, 1]
    accuracy = accuracy_score(y_test, y_pred)
    
    return model, X_test, y_test, y_pred, y_pred_proba, accuracy, X_train

def load_model():
    try:
        with open("model.pkl", "rb") as f:
            model = pickle.load(f)
        return model
    except:
        st.error("Model file not found. Please train the model first.")
        return None

def plot_confusion_matrix(y_test, y_pred):
    conf_matrix = confusion_matrix(y_test, y_pred)
    fig, ax = plt.subplots(figsize=(6, 5))
    sns.heatmap(conf_matrix, annot=True, fmt='d', cmap='Blues', ax=ax, 
                annot_kws={"size": 16}, cbar=False)
    ax.set_title('Confusion Matrix', fontsize=16)
    ax.set_xlabel('Predicted', fontsize=14)
    ax.set_ylabel('Actual', fontsize=14)
    ax.set_xticklabels(['Not Recovered', 'Recovered'], fontsize=12)
    ax.set_yticklabels(['Not Recovered', 'Recovered'], fontsize=12)
    plt.tight_layout()
    st.pyplot(fig)

def plot_roc_curve(y_test, y_pred_proba):
    fpr, tpr, _ = roc_curve(y_test, y_pred_proba)
    roc_auc = auc(fpr, tpr)
    fig, ax = plt.subplots(figsize=(8, 6))
    ax.plot(fpr, tpr, color='#3366ff', lw=2, label=f'ROC curve (AUC = {roc_auc:.3f})')
    ax.plot([0, 1], [0, 1], color='gray', linestyle='--', lw=1.5)
    ax.set_xlabel('False Positive Rate', fontsize=12)
    ax.set_ylabel('True Positive Rate', fontsize=12)
    ax.set_title('Receiver Operating Characteristic (ROC)', fontsize=16)
    ax.legend(loc='lower right', fontsize=10)
    ax.grid(alpha=0.3)
    plt.tight_layout()
    st.pyplot(fig)

def plot_feature_importance(model, X):
    feature_importance = pd.DataFrame({
        'Feature': X.columns,
        'Importance': np.abs(model.coef_[0])
    }).sort_values(by='Importance', ascending=False)
    
    fig, ax = plt.subplots(figsize=(10, 6))
    sns.barplot(x='Importance', y='Feature', data=feature_importance[:10], 
                palette='Blues_d', ax=ax)
    ax.set_title('Top 10 Feature Importance', fontsize=16)
    ax.set_xlabel('Importance (absolute coefficient value)', fontsize=12)
    ax.set_ylabel('Feature', fontsize=12)
    plt.tight_layout()
    st.pyplot(fig)

def plot_data_distribution(df):
    fig, axes = plt.subplots(2, 2, figsize=(14, 10))
    
    # Age distribution by recovery status
    sns.histplot(data=df, x='Age', hue='Recovered', bins=15, ax=axes[0, 0], 
                 palette=['#ff6b6b', '#4ecdc4'])
    axes[0, 0].set_title('Age Distribution by Recovery Status', fontsize=14)
    
    # Lung capacity distribution
    sns.boxplot(data=df, x='Recovered', y='Lung Capacity', ax=axes[0, 1], 
                palette=['#ff6b6b', '#4ecdc4'])
    axes[0, 1].set_title('Lung Capacity by Recovery Status', fontsize=14)
    
    # Hospital visits distribution
    sns.boxplot(data=df, x='Recovered', y='Hospital Visits', ax=axes[1, 0], 
                palette=['#ff6b6b', '#4ecdc4'])
    axes[1, 0].set_title('Hospital Visits by Recovery Status', fontsize=14)
    
    # Disease type distribution
    recovery_by_disease = pd.crosstab(df['Disease Type'], df['Recovered'], normalize='index') * 100
    recovery_by_disease.plot(kind='bar', ax=axes[1, 1], stacked=False, 
                             color=['#ff6b6b', '#4ecdc4'])
    axes[1, 1].set_title('Recovery Rate by Disease Type (%)', fontsize=14)
    axes[1, 1].set_ylabel('Percentage')
    
    plt.tight_layout()
    st.pyplot(fig)

def create_dummy_patient():
    disease_types = ['Asthma', 'COPD', 'Pneumonia', 'Bronchitis', 'Lung Cancer']
    treatment_types = ['Medication', 'Surgery', 'Radiation', 'Combination']
    
    dummy_data = {
        'Age': np.random.randint(25, 75),
        'Gender': np.random.choice(['Male', 'Female']),
        'Smoking Status': np.random.choice(['Never Smoker', 'Former Smoker', 'Current Smoker']),
        'Lung Capacity': round(np.random.normal(75, 15), 1),
        'Disease Type': np.random.choice(disease_types),
        'Treatment Type': np.random.choice(treatment_types),
        'Hospital Visits': np.random.randint(1, 10)
    }
    
    return dummy_data

def main():
    st.markdown("<h1 class='main-header'>🫁 Lung Disease Recovery Prediction</h1>", unsafe_allow_html=True)
    
    df = load_data()
    X, y, df = preprocess_data(df)
    
    # Sidebar for navigation
    st.sidebar.image("logo.png", width=80)  # Replace with a relevant logo
    st.sidebar.title("Navigation")
    page = st.sidebar.radio("Go to", 
                           ["Data Overview", "Model Training", "Make Predictions", "About"])
    
    st.sidebar.markdown("---")
    st.sidebar.info("This application predicts lung disease recovery based on patient characteristics and medical history.")
    
    # Initialize session state for the model
    if 'model' not in st.session_state:
        st.session_state.model = None
    
    if page == "Data Overview":
        st.markdown("<h2 class='sub-header'>Data Overview</h2>", unsafe_allow_html=True)
        st.markdown('<div class="card">', unsafe_allow_html=True)
        
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Total Patients", len(df))
        with col2:
            recovery_rate = (df['Recovered_binary'].mean() * 100).round(1)
            st.metric("Recovery Rate", f"{recovery_rate}%")
        with col3:
            st.metric("Features", len(X.columns))
        
        st.markdown('</div>', unsafe_allow_html=True)
        
        tab1, tab2 = st.tabs(["📊 Data Sample", "📈 Data Visualization"])
        
        with tab1:
            st.dataframe(df.head(10), use_container_width=True)
            
            col1, col2 = st.columns(2)
            with col1:
                st.markdown("<p class='info-text'>Data Summary:</p>", unsafe_allow_html=True)
                st.dataframe(df.describe(), use_container_width=True)
            with col2:
                st.markdown("<p class='info-text'>Missing Values:</p>", unsafe_allow_html=True)
                st.dataframe(pd.DataFrame(df.isnull().sum(), columns=['Missing Values']), use_container_width=True)
        
        with tab2:
            st.markdown("<p class='info-text'>Distribution of key variables by recovery status:</p>", unsafe_allow_html=True)
            plot_data_distribution(df)
    
    elif page == "Model Training":
        st.markdown("<h2 class='sub-header'>Model Training</h2>", unsafe_allow_html=True)
        st.markdown('<div class="card">', unsafe_allow_html=True)
        st.markdown("""
        <p class='info-text'>
        This section trains a logistic regression model to predict patient recovery based on their characteristics and medical history.
        The model will analyze patterns in the data to identify factors associated with successful recovery.
        </p>
        """, unsafe_allow_html=True)
        st.markdown('</div>', unsafe_allow_html=True)
        
        if st.button("Train Model and Evaluate Performance"):
            model, X_test, y_test, y_pred, y_pred_proba, accuracy, X_train = train_and_save_model(X, y)
            st.session_state.model = model
            
            st.markdown("<div class='success-message'>", unsafe_allow_html=True)
            st.markdown("✅ Model trained successfully!", unsafe_allow_html=True)
            st.markdown("</div>", unsafe_allow_html=True)
            
            col1, col2, col3 = st.columns(3)
            with col1:
                st.markdown("<div class='metric-card'>", unsafe_allow_html=True)
                st.metric("Accuracy", f"{accuracy*100:.2f}%")
                st.markdown("</div>", unsafe_allow_html=True)
            with col2:
                st.markdown("<div class='metric-card'>", unsafe_allow_html=True)
                st.metric("Training Samples", len(X_train))
                st.markdown("</div>", unsafe_allow_html=True)
            with col3:
                st.markdown("<div class='metric-card'>", unsafe_allow_html=True)
                st.metric("Test Samples", len(X_test))
                st.markdown("</div>", unsafe_allow_html=True)
            
            tab1, tab2, tab3 = st.tabs(["Confusion Matrix", "ROC Curve", "Feature Importance"])
            
            with tab1:
                plot_confusion_matrix(y_test, y_pred)
            
            with tab2:
                plot_roc_curve(y_test, y_pred_proba)
            
            with tab3:
                plot_feature_importance(model, X)
    
    elif page == "Make Predictions":
        st.markdown("<h2 class='sub-header'>Make Predictions</h2>", unsafe_allow_html=True)
        
        # Try to load a saved model first
        if st.session_state.model is None:
            try:
                st.session_state.model = load_model()
            except:
                pass
        
        # Check if model exists
        if st.session_state.model is None:
            st.warning("No trained model found. Please go to the 'Model Training' page and train a model first.")
        else:
            model = st.session_state.model
            
            st.markdown('<div class="card">', unsafe_allow_html=True)
            st.markdown("""
            <p class='info-text'>
            Enter patient information to predict their recovery probability. 
            You can either input values manually or load sample data for a quick test.
            </p>
            """, unsafe_allow_html=True)
            st.markdown('</div>', unsafe_allow_html=True)
            
            # Add a button to load dummy data
            col1, col2 = st.columns([1, 3])
            with col1:
                if st.button("Load Sample Patient"):
                    st.session_state.dummy_data = create_dummy_patient()
            
            # Initialize dummy data if button clicked
            if 'dummy_data' not in st.session_state:
                st.session_state.dummy_data = {
                    'Age': 55,
                    'Gender': 'Male',
                    'Smoking Status': 'Former Smoker',
                    'Lung Capacity': 75.0,
                    'Disease Type': 'COPD',
                    'Treatment Type': 'Medication',
                    'Hospital Visits': 3
                }
            
            # Create form for patient data
            with st.form(key='prediction_form'):
                col1, col2 = st.columns(2)
                
                with col1:
                    age = st.slider("Age", 18, 100, st.session_state.dummy_data['Age'])
                    gender = st.radio("Gender", options=['Male', 'Female'], index=0 if st.session_state.dummy_data['Gender'] == 'Male' else 1)
                    smoking_status = st.selectbox(
                        "Smoking Status", 
                        options=['Never Smoker', 'Former Smoker', 'Current Smoker'],
                        index=['Never Smoker', 'Former Smoker', 'Current Smoker'].index(st.session_state.dummy_data['Smoking Status'])
                    )
                    lung_capacity = st.slider("Lung Capacity (%)", 10.0, 120.0, st.session_state.dummy_data['Lung Capacity'])
                
                with col2:
                    disease_type = st.selectbox(
                        "Disease Type", 
                        options=['Asthma', 'COPD', 'Pneumonia', 'Bronchitis', 'Lung Cancer'],
                        index=['Asthma', 'COPD', 'Pneumonia', 'Bronchitis', 'Lung Cancer'].index(st.session_state.dummy_data['Disease Type'])
                    )
                    treatment_type = st.selectbox(
                        "Treatment Type", 
                        options=['Medication', 'Surgery', 'Radiation', 'Combination'],
                        index=['Medication', 'Surgery', 'Radiation', 'Combination'].index(st.session_state.dummy_data['Treatment Type'])
                    )
                    hospital_visits = st.slider("Hospital Visits", 1, 20, st.session_state.dummy_data['Hospital Visits'])
                
                submit_button = st.form_submit_button(label='Predict Recovery')
            
            if submit_button:
                # Prepare input data in the same format as training data
                input_data = pd.DataFrame({
                    'Age': [age],
                    'Lung Capacity': [lung_capacity],
                    'Hospital Visits': [hospital_visits],
                    'Gender': [gender],
                    'Smoking Status': [smoking_status],
                    'Disease Type': [disease_type],
                    'Treatment Type': [treatment_type]
                })
                
                # One-hot encode the categorical variables
                input_encoded = pd.get_dummies(input_data)
                
                # Make sure columns match training data
                for col in X.columns:
                    if col not in input_encoded.columns:
                        input_encoded[col] = 0
                
                input_encoded = input_encoded[X.columns]
                
                # Make prediction
                with st.spinner('Generating prediction...'):
                    time.sleep(1)  # Simulate processing time
                    recovery_prob = model.predict_proba(input_encoded)[0][1]
                    prediction = 1 if recovery_prob >= 0.5 else 0
                    result = "Recovered" if prediction == 1 else "Not Recovered"
                
                # Display prediction
                st.markdown("<h3 class='sub-header'>Prediction Result</h3>", unsafe_allow_html=True)
                
                col1, col2 = st.columns([2, 3])
                with col1:
                    if prediction == 1:
                        st.success(f"Prediction: {result}")
                    else:
                        st.error(f"Prediction: {result}")
                    
                    st.metric("Recovery Probability", f"{recovery_prob*100:.1f}%")
                
                with col2:
                    # Create gauge chart for probability
                    fig, ax = plt.subplots(figsize=(4, 1))
                    ax.barh(0, recovery_prob, height=0.3, color='#3366ff')
                    ax.barh(0, 1, height=0.3, color='#e0e0e0', zorder=0)
                    ax.set_xlim(0, 1)
                    ax.set_ylim(-0.5, 0.5)
                    ax.set_yticks([])
                    ax.set_xticks([0, 0.25, 0.5, 0.75, 1])
                    ax.set_xticklabels(['0%', '25%', '50%', '75%', '100%'])
                    ax.spines['right'].set_visible(False)
                    ax.spines['top'].set_visible(False)
                    ax.spines['left'].set_visible(False)
                    plt.tight_layout()
                    st.pyplot(fig)
                
                # Explanation of result
                st.markdown('<div class="card">', unsafe_allow_html=True)
                factors = []
                if age > 65:
                    factors.append("older age")
                if smoking_status == "Current Smoker":
                    factors.append("current smoking status")
                if lung_capacity < 70:
                    factors.append("reduced lung capacity")
                if hospital_visits > 5:
                    factors.append("high number of hospital visits")
                if disease_type == "Lung Cancer":
                    factors.append("disease type (Lung Cancer)")
                
                if prediction == 1:
                    if factors:
                        st.markdown(f"Despite {' and '.join(factors)}, the model predicts recovery. This may be due to other positive factors such as effective treatment or other patient characteristics.")
                    else:
                        st.markdown("The model predicts recovery based on the combination of favorable factors in the patient profile.")
                else:
                    if factors:
                        st.markdown(f"The model predicts non-recovery, which may be influenced by {' and '.join(factors)}.")
                    else:
                        st.markdown("The model predicts non-recovery based on the combination of factors in the patient profile.")
                st.markdown('</div>', unsafe_allow_html=True)
    
    else:  # About page
        st.markdown("<h2 class='sub-header'>About This Application</h2>", unsafe_allow_html=True)
        st.markdown('<div class="card">', unsafe_allow_html=True)
        st.markdown("""
        This application uses machine learning to predict the likelihood of recovery for patients with lung diseases based on their medical profile.
        
        ### How it works:
        1. **Data Collection**: Patient data including demographics, disease characteristics, and treatment information is gathered.
        2. **Preprocessing**: The data is cleaned and prepared for machine learning.
        3. **Model Training**: A logistic regression model is trained to identify patterns associated with recovery.
        4. **Prediction**: The trained model predicts recovery probability for new patients.
        
        ### Important Notes:
        - This is a demonstration tool and should not replace professional medical advice.
        - All predictions are based on statistical patterns and may not account for individual circumstances.
        - Consult with healthcare professionals for actual medical decisions.
        
        ### Dataset Information:
        The model is trained on a dataset containing information about patient demographics, disease characteristics, treatment approaches, and recovery outcomes.
        
        ### Technical Details:
        - Algorithm: Logistic Regression
        - Features: Age, Gender, Smoking Status, Lung Capacity, Disease Type, Treatment Type, Hospital Visits
        - Target: Recovery Status (Yes/No)
        """, unsafe_allow_html=True)
        st.markdown('</div>', unsafe_allow_html=True)

if __name__ == "__main__":
    main()